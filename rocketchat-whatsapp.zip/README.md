# The Rocket.Chat easy integration with Whatsapp™

This plugin is designed to facilitate customer service for companies that use WhatsApp as their primary means of communication.

The idea is to make a call center using Wahtsapp as a communication tool with the client, making multiple attendants respond to customers.
